copy,db1.php,db/
copy,db2.php,docs/